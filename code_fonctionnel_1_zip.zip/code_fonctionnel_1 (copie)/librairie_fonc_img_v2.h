#include <iostream>
#include <fstream>
#include "png_io.h"
using namespace std;


// librairie assombrir : 


//-----------------------------------------------
// Fonction permettant d'assombrir un pixel donné par une valeur donné.
// Entrées : un pixel (type RVB) et la valeur d'assombrissement (type entier)
// Sortie : le pixel assombrit (type RVB)
// Préconditions : valeur_assombrissement > 0


void assombrir_pixel(RVB& pixel, int valeur_assombrissement){

	
    if (pixel.rouge > valeur_assombrissement) {
   	 pixel.rouge = static_cast<Composante>(pixel.rouge - valeur_assombrissement);
    } else {
   	 pixel.rouge = 0;
    }
    
    if (pixel.vert > valeur_assombrissement) {
   	 pixel.vert = static_cast<Composante>(pixel.vert - valeur_assombrissement);
    } else {
   	 pixel.vert = 0;
    }
    
    if (pixel.bleu > valeur_assombrissement) {
   	 pixel.bleu = static_cast<Composante>(pixel.bleu - valeur_assombrissement);
    } else {
   	 pixel.bleu = 0;
    }
}




//-----------------------------------------------
//assombrir image

void assombrir_image(Image_PNG img, int val_assomb, int etape){
	//Variables
	int i, j;
	//Début
	for (i = 0 ; i < static_cast<int>(img.largeur) ; ++i){
    		for (j = 0 ; j < static_cast<int>(img.hauteur) ; ++j){
        		assombrir_pixel(img.pixels[j][i], val_assomb);
    	}
	}
	sauver_PNG("./result/"+std::to_string(etape)+".png", img);  
	

}



//-----------------------------------------------------------------

void griser_pixel(RVB & pixel, int etape, int max_etape){
    if (etape == max_etape){
    pixel.rouge = static_cast<Composante>(pixel.rouge * 0.299 + pixel.vert * 0.587 + pixel.bleu * 0.114);
    pixel.vert = static_cast<Composante>(pixel.rouge * 0.299 + pixel.vert * 0.587 + pixel.bleu * 0.114);
    pixel.bleu = static_cast<Composante>(pixel.rouge * 0.299 + pixel.vert * 0.587 + pixel.bleu * 0.114);
    //     cout << "on est bien" << "\n";
    }
    else {
    
    pixel.rouge = static_cast<Composante>((pixel.vert * 0.587 + ((pixel.vert - pixel.vert * 0.587) / etape)) + (pixel.rouge * 0.299 + (pixel.rouge - pixel.rouge * 0.299) / etape) + (pixel.bleu * 0.114 + ((pixel.bleu - pixel.bleu * 0.114) / etape)));
    pixel.vert = static_cast<Composante>((pixel.vert * 0.587 + ((pixel.vert - pixel.vert * 0.587) / etape)) + (pixel.rouge * 0.299 + (pixel.rouge - pixel.rouge * 0.299) / etape) + (pixel.bleu * 0.114 + ((pixel.bleu - pixel.bleu * 0.114) / etape)));
    pixel.bleu = static_cast<Composante>((pixel.vert * 0.587 + ((pixel.vert - pixel.vert * 0.587) / etape)) + (pixel.rouge * 0.299 + (pixel.rouge - pixel.rouge * 0.299) / etape) + (pixel.bleu * 0.114 + ((pixel.bleu - pixel.bleu * 0.114) / etape)));
    }
    
}



void griser_image(Image_PNG img, int etape, int max_etape){
//Variables
    int i,j;
//Début
    //cout << "feur" << "\n";
    for (i = 0 ; i < static_cast<int>(img.largeur) ; ++i){
   		 for (j = 0 ; j < static_cast<int>(img.hauteur) ; ++j){
   		 //cout << "j'ai lu le pixel" << "\n";
   			 griser_pixel(img.pixels[j][i], etape, max_etape);
   		 
   	 }
    }
    
    sauver_PNG("./result/"+std::to_string(etape)+".png", img);
}


//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/* 
 
   Fonctions de Lucas, comprend entre autre:
   * Masquer
   *     Classique (rideau de ligne unicolore)
   *     Persienne (une ligne toutes les K lignes)
   *
   * Flouter (bug dans la fonction recup_pixel_moyen)
   * Changer taille (pas encore implémenter)
   * Changer taille img A vers img B (pas encore implémenter)
   
*/



//-----------------------------------------------
// Fonction permettant de modifier un pixel donné par de nouvelles couleurs.
// Entrées : un pixel (type RVB) et ses nouvelles valeurs RGB (type entier)
// Sortie : le pixel assombrit (type RVB)
// Préconditions : 255 >= rouge, vert, bleu >= 0

void changer_pixel(RVB& pixel, int rouge, int vert, int bleu){
    pixel.rouge = static_cast<Composante>(rouge);
    pixel.vert = static_cast<Composante>(vert);
    pixel.bleu = static_cast<Composante>(bleu);
}


//-----------------------------------------------
// Ajoute une ligne toutes les K lignes sur une image donnée.

void ajout_ligne_simultanee(Image_PNG& img, int num_etape, int K, int rouge, int vert, int bleu){
	//Variables
	int i, num_ligne;
	//Début
	for (num_ligne = 0 ; num_ligne < static_cast<int>(img.hauteur) ; ++num_ligne){
   	 if ((num_ligne % (K + 1)) == (K - num_etape)){
   		 for (i = 0 ; i < static_cast<int>(img.largeur) ; ++i){
   			 changer_pixel(img.pixels[num_ligne][i], rouge, vert, bleu);
   		 }
   	 }
    }
	sauver_PNG("./result/"+std::to_string(num_etape)+".png", img);  
}

//-----------------------------------------------
// Programme qui applique l'effet masque persien

void masquer_persienne(Image_PNG img, int rouge, int vert, int bleu, int K){
	//Variables
	int i;
	//Début
	for (i = 0 ; i <= K ; ++i){
   	 	ajout_ligne_simultanee(img, i, K, rouge, vert, bleu);
    }
    generer_GIF("./result/", "./gif_result/masquer_persienne_result.gif", 0, K, 0, 0);
}

//-----------------------------------------------
// Ajoute une ligne unicolore sur l'image

void ajout_ligne_classique(Image_PNG& img, int num_ligne, int rouge, int vert, int bleu){
	//Variables
	int num_colonne;
	//Début
    for (num_colonne = 0 ; num_colonne < static_cast<int>(img.largeur) ; ++num_colonne){
   	 	changer_pixel(img.pixels[num_ligne][num_colonne], rouge, vert, bleu);
    }
	sauver_PNG("./result/"+std::to_string(num_ligne)+".png", img);  
}

//-----------------------------------------------
// Programme qui appele en vouybloxye xwDSSSSSS

void masquer_classique(Image_PNG img, int rouge, int vert, int bleu){
	//Variables
	int i;
	//Début
	for (i = 0 ; i < static_cast<int>(img.hauteur) ; ++i){
   	 	ajout_ligne_classique(img, i, rouge, vert, bleu);
    }
    generer_GIF("./result/", "./gif_result/masquer_classique_result.gif", 0, static_cast<int>(img.hauteur)-1, 0, 0);
}

//-----------------------------------------------
// programme qui retourne le pixel moyen sur l'image en récupérant la moyenne des pixels autour de celui visé.

RVB recup_pixel_moyen(Image_PNG img, int pos_pixel_x, int pos_pixel_y, int puissance_floutage){
    //Variables
    int decalage_x, decalage_y, hauteur_img, largeur_img, pix_rouge, pix_vert, pix_bleu, quantite_obtenu, axe_x, axe_y;
    RVB pix_sortie;
    quantite_obtenu = 0;
    pix_rouge = 0;
    pix_vert = 0;
    pix_bleu = 0;
    hauteur_img = static_cast<int>(img.hauteur);
    largeur_img = static_cast<int>(img.largeur);
    
    //Début
    for (decalage_x = puissance_floutage*-1 ; decalage_x <= puissance_floutage ; ++decalage_x){
   	 for (decalage_y = puissance_floutage*-1 ; decalage_y <= puissance_floutage ; ++decalage_y){
   		 axe_x = pos_pixel_x + decalage_x;
   		 axe_y = pos_pixel_y + decalage_y;
   		 if (axe_x >= 0 and axe_y >= 0 and axe_x < largeur_img and axe_y < hauteur_img){
   			 /*
   			 * Début des problèmes
   			 
   			 pix_rouge += img.pixels[axe_x][axe_y].rouge;
   			 pix_vert += img.pixels[axe_x][axe_y].vert;
   			 pix_bleu += img.pixels[axe_x][axe_y].bleu;
   			 
   			 * Fin des problèmes
   			 */
   			 ++quantite_obtenu;
   		 }
   	 }
    }
    
    pix_sortie.rouge = static_cast<Composante>(pix_rouge/quantite_obtenu);
    pix_sortie.vert = static_cast<Composante>(pix_vert/quantite_obtenu);
    pix_sortie.bleu = static_cast<Composante>(pix_bleu/quantite_obtenu);
    return pix_sortie;
}

//-----------------------------------------------
//Programme qui floute l'image entière.

void flouter_image(Image_PNG& img, int puissance_floutage, int num_etape){
    //Variables
    int hauteur_img, largeur_img, num_colonne, num_ligne;
    Image_PNG copie_img = img;
    hauteur_img = static_cast<int>(img.hauteur);
    largeur_img = static_cast<int>(img.largeur);
    
    //Début
    for (num_ligne = 0 ; num_ligne < hauteur_img ; ++num_ligne){
   	 for (num_colonne = 0 ; num_colonne < largeur_img ; ++num_colonne){
   		 img.pixels[num_ligne][num_colonne] = recup_pixel_moyen(copie_img, num_ligne, num_colonne, puissance_floutage);
   	 }
    }
    sauver_PNG("./result/"+std::to_string(num_etape)+".png", img);
}

//-----------------------------------------------
//Programme qui appelle en boucle flouter_image, et en créé un gif. S'arrête au bout de "repetition" itérations.

void gif_flouter_image(Image_PNG img, int repetition, int puissance_floutage){
    //Variables
	int i;
	//Début
	for (i = 0 ; i <= repetition ; ++i){
   	 cout << "yo";
   	 flouter_image(img, puissance_floutage, i);
    }
    generer_GIF("./result/", "./gif_result/flouter_image_result.gif", 0, repetition, 0, 0);
}



